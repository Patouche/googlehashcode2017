package fr.tcd.compute;

/**
 * @author patouche - 2/24/17.
 */
public interface Algorithm {

    void compute();

}
