package fr.tcd.compute;

import fr.tcd.Cache;
import fr.tcd.Endpoint;
import fr.tcd.Request;
import fr.tcd.input.InputData;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * @author patouche - 2/24/17.
 */
public class PaallCacheAlgorithm implements Algorithm {

    private final InputData inputData;

    public PaallCacheAlgorithm(final InputData inputData) {
        this.inputData = inputData;
    }

    @Override
    public void compute() {

        // On définie le compteur d'avancement
        final AtomicLong counter = new AtomicLong(0L);

        // Pour chaque cache
        this.inputData.caches.stream()
                .peek(c -> System.out.printf("Filling cache %d \n", c.id))
                .forEach(cache -> {
                    // On itère sur les requests
                    final Map<Endpoint, List<Request>> endpointRequests = this.inputData.requests.stream()
                            .filter(request -> !cache.videos.contains(request.video))
                            .collect(Collectors.groupingBy(r -> r.endpoint));
                    this.fillCache(cache, endpointRequests);
                });
    }

    private void fillCache(final Cache cache, final Map<Endpoint, List<Request>> endpointRequests) {

        // On cherche le endpoint qui est le plus prêt
        final int availableSpace = cache.getAvailableSpace();

        // Pour endpoint relié au cache
        cache.endpoints.entrySet().stream()
                // Uniquement les endpoints dont les requests n'ont pas été toute cachées
                // .filter(entry -> endpointRequests.getOrDefault(entry.getKey(), Collections.emptyList()).size() > 0)
                // On trie pour avoir le meilleur gain de latence
                // .sorted(Comparator.<Entry<Endpoint, Integer>>comparingInt(ent -> ent.getValue() - ent.getKey().datacenterLatency)
                // .reversed())
                // Plus besoin de la latence => endpoint
                .map(Entry::getKey)
                // Si pour la taille disponible en cache, il existe un endpoint dont il est possible de cacher une vidéo
                // Pour chacun de ces endpoints
                .flatMap(e -> endpointRequests.get(e).stream())
                // On prend les requêtes les plus fréquementes en premier
                .sorted(Comparator.<Request>comparingInt(r -> r.nbRequest).reversed())
                // Pour les vidéos qu'il est possible de cacher
                .filter(r -> r.video.weight <= availableSpace)
                .findFirst()
                .ifPresent(request -> {
                    // On la stocke
                    System.out.printf("Storing video %d in cache %d\n", request.video.id, cache.id);
                    cache.videos.add(request.video);
                    endpointRequests.forEach(((endpoint, requests) -> {
                        endpointRequests.put(endpoint, requests.stream()
                                .filter(r -> r.video != request.video)
                                .collect(Collectors.toList())
                        );
                    }));

                    fillCache(cache, endpointRequests);
                });

    }

}
