package fr.tcd.compute;

import fr.tcd.input.Input;
import fr.tcd.input.InputData;
import fr.tcd.input.InputReader;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author pallain - 2/28/17.
 */
public class PaallCacheAlgorithmTest {

    public static long pointOf(InputData inputData) {
        long nbRequestLong = inputData.requests.stream().mapToLong(request -> request.nbRequest).sum();

//        return inputData.requests.stream().mapToLong(request -> {
//            final int dcLatency = request.endpoint.datacenterLatency;
//            return inputData.caches.stream()
//                    .mapToLong(cache -> dcLatency - cache.endpoints.getOrDefault(request.endpoint, dcLatency))
//                    .map(saved -> saved * request.nbRequest)
//                    .max()
//                    .orElse(0L);
//        }).sum() / nbRequestLong;

        return inputData.requests.stream().flatMapToLong(request -> inputData.caches.stream()
                .mapToLong(cache -> request.endpoint.datacenterLatency
                        - cache.endpoints.getOrDefault(request.endpoint, request.endpoint.datacenterLatency))
                .map(saved -> saved * request.nbRequest))
                .sum() / nbRequestLong;
    }

    @Test
    public void computeMeeAtTheZoo() throws Exception {

        // GIVEN
        final InputData inputData = new InputReader(Input.ME_AT_THE_ZOO.getFilename()).read();
        final PaallCacheAlgorithm algorithm = new PaallCacheAlgorithm(inputData);

        // WHEN
        algorithm.compute();

        // THEN
        assertThat(pointOf(inputData)).isGreaterThanOrEqualTo(411561L);

    }

}
